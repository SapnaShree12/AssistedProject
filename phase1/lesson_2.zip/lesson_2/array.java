package lesson_2;

public class array {
	

		public static void main(String[] args) {

		
		int a[]= {10,20,30,40,50};
		for(int i=0;i<5;i++) {
		System.out.println("the numbers are: "+a[i]);
		}


		
		int[][] b = {
		            {2, 4},{ 6, 8}} ;
		for(int j=0;j<2;j++)
			for(int k=0;k<2;k++)
			{
				System.out.println(b[j][k]);
			}
		}
}
		            
		      
		     
		      
		



