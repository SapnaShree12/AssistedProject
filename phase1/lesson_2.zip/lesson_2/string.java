

	package lesson_2;
public class string {
	public static void main(String[] args) {
		//methods of strings
		System.out.println("Methods of Strings");
	
				String str1 = "this is a book";
				String str2 = new String("this is an apple");
				System.out.println(str1);
				System.out.println(str2);
				System.out.println(str1.length());
				System.out.println(str2.length());
				System.out.println(str2.toUpperCase());
				System.out.println(str2.toLowerCase());
				System.out.println(str2.substring(2));
				System.out.println(str2.substring(2,10));
				System.out.println(str2.indexOf('a'));
				System.out.println(str2.lastIndexOf('a'));
				

}

}
