package lesson_1;

public class specifiers {
	
	
	public static void main(String[] args) {
		//default
		
		defAccessSpecifier a = new defAccessSpecifier(); 		  
        a.display(); 

}
}
	class defAccessSpecifier
	{ 
	  void display() 
	     { 
	         System.out.println("Default access specifierr"); 
	     } 
	} 

