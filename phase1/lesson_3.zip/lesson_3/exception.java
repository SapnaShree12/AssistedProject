package lesson_3;
public class exception
{

	public static void main(String[] args) {
		System.out.println("Hi");
		int a=10;
		int b=0;
		int abc[]= {10,20,30,40,50};
		try {
		int res = a/b;
		System.out.println("Result is "+res);
		int res1 = 100/abc[3];
		System.out.println("result is "+res1);
		}catch(Exception e) {
		
		
			System.out.println(e.toString());	 
		}
		System.out.println("done");
		
	}

}


