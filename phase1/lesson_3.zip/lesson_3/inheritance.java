package lesson_3;


class F{
	void dis1() {
		System.out.println("F class method");
}
}

class E extends F{
void dis2() {
	System.out.println("E class method");
}
}
class inheritance {
public static void main(String args[]) {
F obj1 = new F();
obj1.dis1();

E obj2 = new E();
obj2.dis2();
obj2.dis1();
}
}
