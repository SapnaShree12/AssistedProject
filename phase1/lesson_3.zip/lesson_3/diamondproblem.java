package lesson_3;

interface first{
	default void show()
	{
		System.out.println("this is first method");
	}
}
interface second{
	default void show()
	{
		System.out.println("this is second method");
	}
}


public class diamondproblem implements first,second {
	public void show()
	{
	first.super.show();
	second.super.show();
	}
	
	public static void main(String[]args) {
		diamondproblem obj=new diamondproblem();
		obj.show();
		
	}
}



