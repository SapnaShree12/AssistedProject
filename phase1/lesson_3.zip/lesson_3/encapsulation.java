package lesson_3;


	class Employee {
		private int id;
		private String name;
		private float salary;

		
		public void setValue(int id, String name, float salary) {
			this.id = id;
			this.name = name;
			//this.salary = salary;
			if(salary < 0) {
				this.salary = 8000;
			}else {
				this.salary = salary;
			}
		}
		void displayEmpInfo() {
		System.out.println(" id "+id);
		System.out.println(" name "+name);
		System.out.println(" salary "+salary);	
		}
}

class encapsulation {
	public static void main(String args[]) {
	Employee emp1 = new Employee();
	emp1.setValue(100,"suki",2000);
	emp1.displayEmpInfo();
	}
}


